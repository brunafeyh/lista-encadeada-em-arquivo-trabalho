#include <stdio.h>
#include <stdlib.h>
#include "cabecalho.h"

//Cria uma lista nova em arquivo
//Pré-condição: arquivo aberto para leitura/escrita
//Pós-condição: arquivo é inicializado com uma lista vazia
void cria_lista_vazia(FILE* arq){
    CABECALHO * cab = (CABECALHO*) malloc(sizeof(CABECALHO));
    cab->pos_cabeca = -1;
    cab->pos_topo = 0;
    cab->pos_livre = -1;
    escreve_cabecalho(arq,cab);
    free(cab);
}

//Lê o cabeçaalho do arquivo contendo as informações da lista
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista
//Pós-condição: retorna o ponteiro para o cabe¸calho lido
CABECALHO* le_cabecalho(FILE * arq) {
    CABECALHO * cab = (CABECALHO*) malloc(sizeof(CABECALHO));
    fseek(arq,0,SEEK_SET); // posiciona no início do arquivo
    fread(cab,sizeof(CABECALHO),1,arq);
    return cab;
}

//Escreve no arquivo o cabeçalho contendo as informações da lista
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista
//Pós-condição: cabeçalho escrito no arquivo
void escreve_cabecalho(FILE* arq, CABECALHO* cab){
    fseek(arq,0,SEEK_SET); //posiciona no início do arquivo
    fwrite(cab,sizeof(CABECALHO),1,arq);
}
