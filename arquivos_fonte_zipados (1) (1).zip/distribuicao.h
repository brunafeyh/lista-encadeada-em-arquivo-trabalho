#ifndef DISTRIBUICAO_H
#define DISTRIBUICAO_H
#include "disciplina.h"
#include "file.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"

typedef struct{
    int cod_disciplina;
    int ano_letivo;
    int cod_professor;
} DISTRIBUICAO;

typedef struct{
    DISTRIBUICAO distribuicao;
    int prox;
} NO_DISTRIBUICAO;

DISTRIBUICAO ler_distribuicao();
NO_DISTRIBUICAO* le_no_distribuicao(FILE* file_distribuicao, int pos);
void escreve_no_distribuicao(FILE* file_distribuicao, NO_DISTRIBUICAO * distribuicao, int pos);
void inserir_distribuicao_file(FILE* file_distribuicao, DISTRIBUICAO distribuicao);
void imprimir_info_distribuicao(NO_DISTRIBUICAO * no_distribuicao, NO_DISCIPLINA no_disciplina, NO_CURSO no_curso, NO_PROFESSOR no_professor);
void header_lista_distribuicao();
void linha_final_lista_distribuicao();
int ler_ano();
int verifica_ano_distribuicao(FILE * file_distribuicao, int ano);
void imprimir_lista_distribuicao(ARQUIVOS files);
void retira_distribuicao(FILE* file_distribuicao, int codigo, int ano);

#endif //DISTRIBUICAO_H
