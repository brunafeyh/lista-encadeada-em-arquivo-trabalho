#include <stdio.h>
#include "file.h"
#include "cabecalho.h"

//Verificar se os arquivos bin�rios j� existem ou n�o
//Pr�-condi��o: nenhuma
//P�s-condi��o: se aqrquivos existirem, ent�o s�o abertos para leitura e escrita. Caso contr�rio, s�o criados e inicializados com uma lista vazia
void verificar_arquivos(ARQUIVOS * files){

    if((files->file_curso = fopen("curso.bin", "r+b")) == NULL){
        printf("CRIANDO ARQUIVO DE CURSO...\n");
        files->file_curso = fopen("curso.bin", "w+b");
        cria_lista_vazia(files->file_curso);
    }

    if((files->file_disciplina = fopen("disciplina.bin", "r+b")) == NULL){
        printf("CRIANDO ARQUIVO DE DISCIPLINA...\n");
        files->file_disciplina = fopen("disciplina.bin", "w+b");
        cria_lista_vazia(files->file_disciplina);
    }

    if((files->file_professor = fopen("professor.bin", "r+b")) == NULL){
        printf("CRIANDO ARQUIVO DE PROFESSOR...\n");
        files->file_professor = fopen("professor.bin", "w+b");
        cria_lista_vazia(files->file_professor);
    }

    if((files->file_distribuicao = fopen("distribuicao.bin", "r+b")) == NULL){
        printf("CRIANDO ARQUIVO DE DISTRIBUICAO...\n");
        files->file_distribuicao = fopen("distribuicao.bin", "w+b");
        cria_lista_vazia(files->file_distribuicao);
    }

    printf("\n");

}

//Fecha os aqrquivos
//Pr�-condi��o: nenhuma
//P�s-condi��o: arquivos fechados
void fechar_arquivos(ARQUIVOS * files){
    fclose(files->file_curso);
    fclose(files->file_disciplina);
    fclose(files->file_professor);
    fclose(files->file_distribuicao);
}

//Verifica se um arquivo est� vazio ou n�o, isto �: se contem registros ou n�o
//Pr�-condi��o: nenhuma
//P�s-condi��o: retorna 1 se h� registros e 0 caso n�o
int is_vazio(FILE * file){
    CABECALHO * cab = le_cabecalho(file);
    return (cab->pos_topo == 0);
}
