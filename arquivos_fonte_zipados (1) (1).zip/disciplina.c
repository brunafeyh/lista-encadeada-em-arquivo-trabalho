#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "disciplina.h"
#include "cabecalho.h"
#include "file.h"

//Instancia uma struct DISCIPLINA com as informações da disciplina que serão gravadas no arquivo
//Pré-condição: nenhuma
//Pós-condição: retorno é uma struct DISCIPLINA
DISCIPLINA ler_disciplina(){
    DISCIPLINA disciplina;

    printf("\n--> CADASTRO DE DISCIPLINA: \n");
    printf("Insira o codigo da disciplina: ");
    scanf("%d%*c", &disciplina.codigo);
    printf("Insira o nome da disciplina: ");
    scanf("%[^\n]%*c", disciplina.nome);
    printf("Insira o codigo do curso da disciplina: ");
    scanf("%d", &disciplina.cod_curso);
    printf("Insira a serie da disciplina: ");
    scanf("%d", &disciplina.serie);

    return disciplina;
}

//lê um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
//Pós-condição: ponteiro para nó lido é retornado
NO_DISCIPLINA * le_no_disciplina(FILE* file_disciplina, int pos){
    NO_DISCIPLINA * no_disciplina = malloc(sizeof(NO_DISCIPLINA));
    fseek(file_disciplina, sizeof(CABECALHO)+ pos*sizeof(NO_DISCIPLINA), SEEK_SET);
    fread(no_disciplina, sizeof(NO_DISCIPLINA), 1, file_disciplina);
    return no_disciplina;
}

//Escreve um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
//Pós-condição: nó escrito no arquivo
void escreve_no_disciplina(FILE* file_disciplina, NO_DISCIPLINA * no_disciplina, int pos){
    fseek(file_disciplina, sizeof(CABECALHO)+ pos*sizeof(NO_DISCIPLINA), SEEK_SET);
    fwrite(no_disciplina, sizeof(NO_DISCIPLINA), 1, file_disciplina);
}

//Insere um nó contendo as informações da disciplina em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto
//Pós-condição: nó escrito no arquivo
void inserir_disciplina_file(FILE* file_disciplina, DISCIPLINA disciplina){
    CABECALHO * cab = le_cabecalho(file_disciplina);
    NO_DISCIPLINA no_disciplina;

    //Neste momento, criamos um nó da disciplina (contendo os dados da disciplina)
    no_disciplina.disciplina.codigo = disciplina.codigo;
    strcpy(no_disciplina.disciplina.nome, disciplina.nome);
    no_disciplina.disciplina.cod_curso = disciplina.cod_curso;
    no_disciplina.disciplina.serie = disciplina.serie;

    //o item prox do no recebe o valor lido do cabeçalho do arquivo
    no_disciplina.prox = cab->pos_cabeca;

    if(cab->pos_livre == -1) { // não há nós livres, então usar o topo
        escreve_no_disciplina(file_disciplina, &no_disciplina, cab->pos_topo);
        cab->pos_cabeca = cab->pos_topo;
        cab->pos_topo++;
    }
    else { // usar nó da lista de livres
        NO_DISCIPLINA * aux = le_no_disciplina(file_disciplina, cab->pos_livre);
        escreve_no_disciplina(file_disciplina, &no_disciplina, cab->pos_livre);
        cab->pos_cabeca = cab->pos_livre;
        cab->pos_livre = aux->prox;
        free(aux);
    }
    escreve_cabecalho(file_disciplina, cab);
    free(cab);
}

//Imprime as informações de uma determinada disciplina na tela
//Pré-condição: nenhuma
//Pós-condição: informações impressas na tela
void imprimir_info_disciplina(NO_DISCIPLINA no_disciplina, NO_CURSO no_curso){
    printf("| %03d    ", no_disciplina.disciplina.codigo);
    printf("%-50s", no_disciplina.disciplina.nome);
    printf("%4d       ", no_disciplina.disciplina.cod_curso);
    printf("%-51s ", no_curso.curso.nome);
    printf("%10d |\n", no_disciplina.disciplina.serie);
}

//Imprime as informações de todas as disciplinas registradas, em uma lista
//Pré-condição: arquivo deve conter registros de disciplina
//Pós-condição: informações impressas na tela
void imprimir_lista_disciplinas(ARQUIVOS files){
    NO_DISCIPLINA no_disciplina;
    NO_CURSO no_curso;

    if(!is_vazio(files.file_disciplina)){
        fseek(files.file_disciplina, sizeof(CABECALHO), SEEK_SET);

        printf(" -----------------------------------------------------LISTA DE DISCIPLINAS-----------------------------------------------------------\n");
        printf("| COD.   NOME                                            COD. CURSO   NOME CURSO                                               SERIE |\n");
        if(files.file_disciplina){
            while(fread(&no_disciplina, sizeof(NO_DISCIPLINA), 1, files.file_disciplina) == 1){
                no_curso = buscar_curso_file(files.file_curso, no_disciplina.disciplina.cod_curso);
                imprimir_info_disciplina(no_disciplina, no_curso);
            }
        }
        printf(" ------------------------------------------------------------------------------------------------------------------------------------\n");
    }else{
        printf("\n--> Nao ha disciplinas registrados!\n\n");
    }
}

//Localiza uma disciplina através de seu código
//Pré-condição: nenhuma
//Pós-condição: as informações da disciplina são retornadas em uma struct do tipo NO_DISCIPLINA
NO_DISCIPLINA buscar_disciplina_file(FILE * file_disciplina, int codigo){
    NO_DISCIPLINA no_disciplina;

    if(!is_vazio(file_disciplina)){
        fseek(file_disciplina, sizeof(CABECALHO), SEEK_SET);

        while(fread(&no_disciplina, sizeof(NO_DISCIPLINA), 1, file_disciplina) == 1){
            if(no_disciplina.disciplina.codigo == codigo){
                return no_disciplina; //no momento em que encontra o código desejado, retorna as informações
            }
        }
    }
    return no_disciplina;
}
