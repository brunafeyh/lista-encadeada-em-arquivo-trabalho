#ifndef MENU_H
#define MENU_H
#include "file.h"

void header_menu();
void header_cadastrar();
void header_remover();
void header_imprimir();
void header_carregar_arquivo();
void menu_cadastrar(ARQUIVOS files);
void menu_remover(ARQUIVOS files);
void menu_imprimir(ARQUIVOS files);
void menu_carregar_arquivo(ARQUIVOS files);
void menu_principal(ARQUIVOS files);

#endif //MENU_H
