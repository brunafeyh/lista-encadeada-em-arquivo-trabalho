#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "curso.h"
#include "cabecalho.h"
#include "file.h"

//Instancia uma struct GRADUACAO com as informações do curso que serão gravadas no arquivo
//Pré-condição: nenhuma
//Pós-condição: retorno é uma struct GRADUACAO
GRADUACAO ler_curso(){
    GRADUACAO curso;
    printf("\n--> CADASTRO DE CURSO: \n");
    printf("Insira o codigo do curso: ");
    scanf("%d%*c", &curso.codigo);
    printf("Insira o nome do curso: ");
    scanf("%[^\n]%*c", curso.nome);
    printf("Insira a area do curso: ");
    scanf("%c", &curso.area);

    return curso;
}

//lê um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
//Pós-condição: ponteiro para nó lido é retornado
NO_CURSO * le_no_curso(FILE* file_curso, int pos){
    NO_CURSO * no_graduacao = malloc(sizeof(NO_CURSO));
    fseek(file_curso, sizeof(CABECALHO)+ pos*sizeof(NO_CURSO), SEEK_SET);
    fread(no_graduacao, sizeof(NO_CURSO), 1, file_curso);
    return no_graduacao;
}

//Escreve um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
//Pós-condição: nó escrito no arquivo
void escreve_no_curso(FILE* file_curso, NO_CURSO * no_graduacao, int pos){
    fseek(file_curso, sizeof(CABECALHO)+ pos*sizeof(NO_CURSO), SEEK_SET);
    fwrite(no_graduacao, sizeof(NO_CURSO), 1, file_curso);
}

//Insere um nó contendo as informações do curso em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto
//Pós-condição: nó escrito no arquivo
void inserir_curso_file(FILE* file_curso, GRADUACAO curso){
    CABECALHO * cab = le_cabecalho(file_curso);
    NO_CURSO no_graduacao;

    //Neste momento, criamos um nó da graduação (contento uma estrutura com os dados do curso e o item prox)
    no_graduacao.curso.codigo = curso.codigo;
    strcpy(no_graduacao.curso.nome, curso.nome);
    no_graduacao.curso.area = curso.area;

    //o item prox do no recebe o valor lido do cabeçalho do arquivo
    no_graduacao.prox = cab->pos_cabeca;

    if(cab->pos_livre == -1) { // não há nós livres, então usar o topo
        escreve_no_curso(file_curso, &no_graduacao, cab->pos_topo);
        cab->pos_cabeca = cab->pos_topo;
        cab->pos_topo++;
    }
    else { // usar nó da lista de livres
        NO_CURSO * aux = le_no_curso(file_curso, cab->pos_livre);
        escreve_no_curso(file_curso, &no_graduacao, cab->pos_livre);
        cab->pos_cabeca = cab->pos_livre;
        cab->pos_livre = aux->prox;
        free(aux);
    }
    escreve_cabecalho(file_curso, cab);
    free(cab);
}

//Imprime as informações de um determinado curso na tela
//Pré-condição: nenhuma
//Pós-condição: informações impressas na tela
void imprimir_info_curso(NO_CURSO no_graduacao){
    printf("| %03d    ", no_graduacao.curso.codigo);
    printf("%-50s", no_graduacao.curso.nome);
    printf("%c  |\n", no_graduacao.curso.area);
}

//Imprime as informações de todos os cursos registrados, em uma lista
//Pré-condição: arquivo deve conter registros de curso
//Pós-condição: informações impressas na tela
void imprimir_lista_cursos(FILE * file_curso){
    NO_CURSO no_graduacao;

    if(!is_vazio(file_curso)){
        fseek(file_curso, sizeof(CABECALHO), SEEK_SET);

        printf(" ----------------------LISTA DE CURSOS------------------------\n");
        printf("| COD.   NOME                                            AREA |\n");
        if(file_curso){
            while(fread(&no_graduacao, sizeof(NO_CURSO), 1, file_curso) == 1){
                imprimir_info_curso(no_graduacao);
            }
        }
        printf(" -------------------------------------------------------------\n");
    }else{
        printf("\n--> Nao ha cursos registrados!\n\n");
    }
}

//Localiza um curso através de seu código
//Pré-condição: nenhuma
//Pós-condição: as informações do curso são retornadas em uma struct do tipo NO_CURSO
NO_CURSO buscar_curso_file(FILE * file_curso, int codigo){
    NO_CURSO no_curso;

    if(!is_vazio(file_curso)){
        fseek(file_curso, sizeof(CABECALHO), SEEK_SET);

        while(fread(&no_curso, sizeof(NO_CURSO), 1, file_curso) == 1){
            if(no_curso.curso.codigo == codigo){
                return no_curso; //no momento em que encontra o código desejado, retorna as informações
            }
        }
    }

    return no_curso;
}
