#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "distribuicao.h"
#include "cabecalho.h"
#include "file.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"

//Instancia uma struct DISTRIBUICAO com as informações da distribuição que serão gravadas no arquivo
//Pré-condição: nenhuma
//Pós-condição: retorno é uma struct DISTRIBUICAO
DISTRIBUICAO ler_distribuicao (){
    DISTRIBUICAO distribuicao;

    printf("\n--> CADASTRO DE DISTRIBUICAO DE DISCIPLINA: \n");
    printf ("Insira o codigo da disciplina: ");
    scanf ("%d", &distribuicao.cod_disciplina);
    printf ("Insira o ano letivo: ");
    scanf ("%d", &distribuicao.ano_letivo);
    printf ("Insira o codigo do professor: ");
    scanf ("%d", &distribuicao.cod_professor);

    return distribuicao;
}

//lê um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
//Pós-condição: ponteiro para nó lido é retornado
NO_DISTRIBUICAO * le_no_distribuicao (FILE * file_distribuicao, int pos){
    NO_DISTRIBUICAO * no_distribuicao = malloc (sizeof (NO_DISTRIBUICAO));
    fseek (file_distribuicao, sizeof (CABECALHO) + pos * sizeof (NO_DISTRIBUICAO), SEEK_SET);
    fread (no_distribuicao, sizeof (NO_DISTRIBUICAO), 1, file_distribuicao);
    return no_distribuicao;
}

//Escreve um nó em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
//Pós-condição: nó escrito no arquivo
void escreve_no_distribuicao (FILE * file_distribuicao, NO_DISTRIBUICAO * no_distribuicao, int pos){
    fseek (file_distribuicao,
    sizeof (CABECALHO) + pos * sizeof (NO_DISTRIBUICAO), SEEK_SET);
    fwrite (no_distribuicao, sizeof (NO_DISTRIBUICAO), 1, file_distribuicao);
}

//Insere um nó contendo as informações da distribuição em uma determinada posição do arquivo
//Pré-condição: arquivo deve estar aberto
//Pós-condição: nó escrito no arquivo
void inserir_distribuicao_file (FILE * file_distribuicao, DISTRIBUICAO distribuicao){
    CABECALHO *cab = le_cabecalho (file_distribuicao);
    NO_DISTRIBUICAO no_distribuicao;

    //Neste momento, criamos um nó da distribuição (contendo os dados da distribuição)
    no_distribuicao.distribuicao.cod_disciplina = distribuicao.cod_disciplina;
    no_distribuicao.distribuicao.ano_letivo = distribuicao.ano_letivo;
    no_distribuicao.distribuicao.cod_professor = distribuicao.cod_professor;

    //o item prox do no recebe o valor lido do cabeçalho do arquivo
    no_distribuicao.prox = cab->pos_cabeca;

    if (cab->pos_livre == -1){				// não há nós livres, então usar o topo
        escreve_no_distribuicao (file_distribuicao, &no_distribuicao,cab->pos_topo);
        cab->pos_cabeca = cab->pos_topo;
        cab->pos_topo++;
    }else{				// usar nó da lista de livres
        NO_DISTRIBUICAO *aux =
	    le_no_distribuicao (file_distribuicao, cab->pos_livre);
	    escreve_no_distribuicao (file_distribuicao, &no_distribuicao,cab->pos_livre);
        cab->pos_cabeca = cab->pos_livre;
        cab->pos_livre = aux->prox;
        free (aux);
    }
    escreve_cabecalho (file_distribuicao, cab);
    free (cab);
}

//Imprime as informações de uma determinada distribuição na tela
//Pré-condição: nenhuma
//Pós-condição: informações impressas na tela
void imprimir_info_distribuicao (NO_DISTRIBUICAO * no_distribuicao, NO_DISCIPLINA no_disciplina, NO_CURSO no_curso, NO_PROFESSOR no_professor){
    printf ("| %03d               ", no_distribuicao->distribuicao.cod_disciplina);
    printf ("%-51s ", no_disciplina.disciplina.nome);
    printf ("%-30s ", no_curso.curso.nome);
    printf ("%9d ", no_distribuicao->distribuicao.ano_letivo);
    printf ("%13d         ", no_distribuicao->distribuicao.cod_professor);
    printf ("%-30s|    \n", no_professor.professor.nome);
}

//Retira um nó da lista
//Pré-condição: arquivo deve estar aberto e ser um arquivo de lista
//Pós-condição: nó retirado da lista caso pertença a ela
void retira_distribuicao(FILE* file_distribuicao, int codigo, int ano){
    CABECALHO * cab = le_cabecalho(file_distribuicao);
    int pos_aux = cab->pos_cabeca;
    int pos_ant = cab->pos_cabeca;
    NO_DISTRIBUICAO * aux = NULL;

    while(pos_aux != -1 // procura o elemento a ser retirado
          && ((aux = le_no_distribuicao(file_distribuicao, pos_aux))!= NULL)
          && (aux->distribuicao.cod_disciplina != codigo
          || ((aux->distribuicao.cod_disciplina == codigo) && aux->distribuicao.ano_letivo != ano))){
        pos_ant = pos_aux;
        pos_aux = aux->prox;
        free(aux);
        aux = NULL;
    }

    if(pos_aux != -1) { //encontrou o elemento
        if(pos_ant == pos_aux){ // remoção na cabeça
            cab->pos_cabeca = aux->prox;
        }
        else { // remoção no meio
            NO_DISTRIBUICAO * ant = le_no_distribuicao(file_distribuicao, pos_ant);
            ant->prox = aux->prox;
            escreve_no_distribuicao(file_distribuicao, ant, pos_ant);
            free(ant);
        }
        aux->prox = cab->pos_livre; // torna o nó removido um nó livre
        cab->pos_livre = pos_aux;
        escreve_no_distribuicao(file_distribuicao, aux, pos_aux);
        escreve_cabecalho(file_distribuicao, cab);
        free(aux);
        printf("--> Distribuicao removida com sucesso!\n");
    }else if(pos_aux == -1) printf("--> Distribuicao nao encontrada!\n");
    free(cab);
}


void header_lista_distribuicao(){
    printf("\n");
    printf(" ------------------------------------------------------------------LISTA DE DISTRIBUICAO-----------------------------------------------------------------------------\n");
    printf("|                                                                                                                                                                    |\n");
    printf("| COD. DISCIPLINA | DISCIPLINA                                         | CURSO                        | ANO LETIVO  | COD. PROFESSOR | PROFESSOR                     |\n");
}

void linha_final_lista_distribuicao(){
    printf("|                                                                                                                                                                    |\n");
    printf (" --------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
}

int ler_ano(){
    int ano;
    printf("\n--> Digite o ano letivo de distribuicao de disciplinas: ");
    scanf("%d", &ano);
    return ano;
}

//Verifica se existe alguma disciplina com um determinado ano
//Pré-condição: nenhuma
//Pós-condição: retorna 1 se existir pelo menos uma disciplina com um determinado ano informado pelo usuário e 0 caso contrário
int verifica_ano_distribuicao(FILE * file_distribuicao, int ano){
    CABECALHO * cab = le_cabecalho(file_distribuicao);
    NO_DISTRIBUICAO * aux;

    aux = le_no_distribuicao(file_distribuicao, cab->pos_cabeca);

    while(aux->prox != -1){ // este while percorre todas as distribuicoes cadastradas em distribuicao.bin
        if(aux->distribuicao.ano_letivo == ano){ //Condição 1: Aqui verifica-se se a distribuição possui o mesmo ano digitado pelo usuário
            free(aux);
            return 1;
        }
        aux = le_no_distribuicao(file_distribuicao, aux->prox);//copia o próximo item para a struct auxiliar
    }

    free(aux);
    return 0;
}

//Imprime as informações de todas as distribuições registradas, em uma lista
//Pré-condição: arquivo deve conter registros de distribuições
//Pós-condição: informações impressas na tela, organizadas por curso e ano letivo
 void imprimir_lista_distribuicao(ARQUIVOS files){
    CABECALHO * cab = le_cabecalho(files.file_distribuicao);
    NO_CURSO no_curso;
    NO_PROFESSOR no_professor;
    NO_DISCIPLINA no_disciplina;
    NO_DISTRIBUICAO * aux;

    int ano;

    if(cab->pos_cabeca != -1){
        ano = ler_ano();
        aux = le_no_distribuicao(files.file_distribuicao, cab->pos_cabeca);//copia a "cabeça do arquivo para a struct - aux -
        fseek (files.file_curso, sizeof (CABECALHO), SEEK_SET); //Necessário pular o cabeçalho de curso.bin para começar a leitura de informações de cursos

        if(verifica_ano_distribuicao(files.file_distribuicao, ano)){
            header_lista_distribuicao();
        }else{
            printf("\n--> Nao ha distribuicoes registrados!\n\n");
        }

        while(fread(&no_curso, sizeof (NO_CURSO), 1, files.file_curso) == 1){ //Este while percorre todos os cursos cadastrados em curso.bin
            aux = le_no_distribuicao(files.file_distribuicao, cab->pos_cabeca);

            while(aux->prox != -1){ // este while percorre todas as distribuicoes cadastradas em distribuicao.bin
                no_disciplina = buscar_disciplina_file(files.file_disciplina, aux->distribuicao.cod_disciplina);
                no_professor = buscar_professor_file(files.file_professor, aux->distribuicao.cod_professor);

                if(aux->distribuicao.ano_letivo == ano){ //Condição 1: Aqui verifica-se se a distribuição possui o mesmo ano digitado pelo usuário
                    if(no_disciplina.disciplina.cod_curso == no_curso.curso.codigo){ // Condição 2: Aqui verifica-se se a distribuição possui o mesmo código do curso que foi lido de curso.bin
                        imprimir_info_distribuicao (aux, no_disciplina, no_curso, no_professor); //Caso as condições 1 e 2 sejam verdadeiras, a impressão das informações é realizada
                    }
                }

                aux = le_no_distribuicao(files.file_distribuicao, aux->prox);//copia o próximo item para a struct auxiliar
            }

            no_disciplina = buscar_disciplina_file(files.file_disciplina, aux->distribuicao.cod_disciplina);
            no_professor = buscar_professor_file(files.file_professor, aux->distribuicao.cod_professor);

            if(no_disciplina.disciplina.cod_curso == no_curso.curso.codigo && aux->distribuicao.ano_letivo == ano)
                imprimir_info_distribuicao (aux, no_disciplina, no_curso, no_professor);//imprime a última posição

        }

        if(verifica_ano_distribuicao(files.file_distribuicao, ano)){
            linha_final_lista_distribuicao();
        }

        free(aux);
    }else{
        printf("\n--> Nao ha distribuicoes registrados!\n\n");
    }
}
