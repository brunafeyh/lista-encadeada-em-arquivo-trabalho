#ifndef FILE_H
#define FILE_H

typedef struct{
    FILE *file_curso;
    FILE *file_disciplina;
    FILE *file_professor;
    FILE *file_distribuicao;
} ARQUIVOS;

void verificar_arquivos(ARQUIVOS * files);
void fechar_arquivos(ARQUIVOS * files);
int is_vazio(FILE * file);

#endif //FILE_H
