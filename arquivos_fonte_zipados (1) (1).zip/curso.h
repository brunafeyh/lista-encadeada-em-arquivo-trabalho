#ifndef CURSO_H
#define CURSO_H
#define MAXS 51

typedef struct{
    int codigo;
    char nome[MAXS];
    char area;
} GRADUACAO;

typedef struct{
    GRADUACAO curso;
    int prox;
} NO_CURSO;

GRADUACAO ler_curso();
NO_CURSO * le_no_curso(FILE* file_curso, int pos);
void escreve_no_curso(FILE* file_curso, NO_CURSO * graduacao, int pos);
void inserir_curso_file(FILE* file_curso, GRADUACAO curso);
void imprimir_info_curso(NO_CURSO no_graduacao);
void imprimir_lista_cursos(FILE * file_curso);
NO_CURSO buscar_curso_file(FILE * file_curso, int codigo);

#endif //CURSO_H

