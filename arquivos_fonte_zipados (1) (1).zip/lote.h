#ifndef LOTE_H
#define LOTE_H
#include "file.h"

void inserir_lote(ARQUIVOS files);
void registrar_lote_curso(FILE * file_lote, FILE * file_curso);
void registrar_lote_disciplina(FILE * file_lote, FILE * file_disciplina);
void registrar_lote_professor(FILE * file_lote, FILE * file_professor);
void registrar_lote_distribuicao(FILE * file_lote, FILE * file_distribuicao);

#endif //LOTE_H
