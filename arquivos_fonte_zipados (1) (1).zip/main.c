#include <stdio.h>
#include "menu.h"
#include "cabecalho.h"
#include "file.h"


int main()
{
    ARQUIVOS files;

    verificar_arquivos(&files);

    menu_principal(files);

    fechar_arquivos(&files);

    return 0;
}
